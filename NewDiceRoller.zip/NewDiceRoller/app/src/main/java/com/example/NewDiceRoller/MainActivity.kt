package com.example.diceroller
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnRoll: Button = findViewById(R.id.botaoDR)

        btnRoll.setOnClickListener {
            rollDice()
        }
    }

    private fun rollDice() {


        val diceRoll = (1..6).random()
        val diceImage: ImageView = findViewById(R.id.imageView)

        val drawableResource = when (diceRoll) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }

        diceImage.setImageResource(drawableResource)

        val txtNumero: TextView = findViewById(R.id.txtNumero)
        val txtCaixa: TextView = findViewById(R.id.txtCaixa)
        var NumeroF: EditText = findViewById(R.id.SortNum)

        txtNumero.text = diceRoll.toString()

        if(diceRoll == NumeroF.text.toString().toInt()){
            Toast.makeText(this, "Você ganhou", Toast.LENGTH_SHORT).show()
        }

        else{
            Toast.makeText(this, "Você perdeu", Toast.LENGTH_SHORT).show()
        }

    }

}